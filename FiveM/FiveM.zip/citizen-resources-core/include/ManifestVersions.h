"77731fab-63ca-442c-a67b-abc70f28dfa5", // 2016-12 release
"f15e72ec-3972-4fe4-9c7d-afc5394ae207", // 2017-04-08
"44febabe-d386-4d18-afbe-5e627f4af937", // 2017-06-06 (swapped around as it's a 'core' feature)
"05cfa83c-a124-4cfa-a768-c24a5811d8f9", // 2017-06-03
