#ifndef __D3D10_IMPL_H__
#define __D3D10_IMPL_H__

#include "shared.h"

namespace impl
{
	namespace d3d10
	{
		void init();
	}
}

#endif // __D3D10_IMPL_H__